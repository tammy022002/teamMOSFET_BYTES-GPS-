from django.db import models

# Create your models here.
class image_save(models.Model) :
    phone_no=models.CharField(max_length=10)
    image=models.ImageField(upload_to="img/%y")

    def __str__(self) :
        return self.phone_no

