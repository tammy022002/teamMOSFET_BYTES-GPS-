from django.shortcuts import render,HttpResponse, redirect
from .models import image_save
from django.contrib.auth import authenticate
from django.contrib.auth import logout ,login
from django.contrib.auth.models import User
import qrcode 

def index(request):
    return render(request , "homepage.html")

def l_save(request):
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request ,"vendor.html")
    


def log_in(request):
    if request.method =="POST" :
        username=request.POST.get("username")
        password=request.POST.get("password")
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request ,user)
            return redirect("/vendor")
        
        else :
            return render(request ,"login.html")
    return render(request ,"login.html")

def log_out(request) :
    logout(request)
    return redirect("/login")


def about(request):
    return render(request , "about.html")

def vendor(request):
    return render(request , "vendor.html")

def sign_up(request) :
    if request.method =="POST" :
        name=request.POST.get("name")
        surname=request.POST.get("surname")
        email=request.POST.get("email")
        password=request.POST.get("password")
        user = User.objects.create_user(username=name, email=email, password=password)
        user.save()
        return redirect("/login")

    return render(request, "signup.html")

def scan(request) :
    return render(request ,"scanner.html")


def generate_qr(request) :
    img = qrcode.make('Some data here')
    type(img)  # qrcode.image.pil.PilImage
    a=img.save("some_fle.png")
    Save=image_save(image=a)
    Save.save()
    url=image_save.objects.all()
    total=len(url)
    value=url[total-1]
    ac_link=value.image
    final_url={"link" :ac_link}
    

    
    return render(request ,"generator.html", context=final_url)