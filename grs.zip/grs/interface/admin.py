from django.contrib import admin
from interface.models import image_save

# Register your models here.
admin.site.register(image_save)
